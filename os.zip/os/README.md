CS4411
======
We haven't tested our project except for on the first test provided. This was because we struggled with it up until the last few hours, when we were able to fix some bugs and pass the first test but did not have time to make additional progress.

We did not implement the ack/sequence number technique to enforce an ordering on the stream. This, again, was due to the time constraint. 

Steven (say25) did most of the initial coding, Mitchell (mjv58) did most of the testing and debugging - this was consistent with our schedules, as Mitch was busy last week and Steven is busy this week. 

Happy TA'ing! We found this project by far to be the most difficult in the practicum thus far. 

- Mitch and Steven
